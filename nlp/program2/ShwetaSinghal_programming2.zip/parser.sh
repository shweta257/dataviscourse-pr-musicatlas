python parser.py grammar.txt sentences.txt
